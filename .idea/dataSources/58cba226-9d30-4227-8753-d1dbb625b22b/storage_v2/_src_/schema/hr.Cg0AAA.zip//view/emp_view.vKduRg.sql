create definer = root@localhost view emp_view as
select `e`.`employee_id` AS `employee_id`, `d`.`department_name` AS `department_name`, `l`.`city` AS `city`
from ((`hr`.`employees` `e` join `hr`.`departments` `d` on (`e`.`department_id` = `d`.`department_id`))
         join `hr`.`locations` `l` on (`d`.`location_id` = `l`.`location_id`));

