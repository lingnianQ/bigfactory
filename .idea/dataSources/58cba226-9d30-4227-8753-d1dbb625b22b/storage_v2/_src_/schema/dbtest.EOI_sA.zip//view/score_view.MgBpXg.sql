create definer = root@localhost view score_view as
select `st`.`name` AS `student_name`, `co`.`name` AS `course_name`, `sc`.`score` AS `score`
from ((`dbtest`.`student` `st` join `dbtest`.`score` `sc` on ((`st`.`id` = `sc`.`sid`)))
         join `dbtest`.`course` `co` on ((`sc`.`cid` = `co`.`id`)))
where ((`st`.`name` = 'Jack') and (`co`.`name` = 'mysql'));

