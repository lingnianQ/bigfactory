create
    definer = root@localhost procedure insert_t1()
begin
    declare i int;                    
    set i=1;                          
    while(i<=1000000)
        do                  
    insert into t1(a,b) values(i, i); 
    set i=i+1;                      
        end while;
end;

