create
    definer = root@localhost procedure insert_t1()
begin
    declare i int;                    /* 声明变量i */
    set i=1;                          /* 设置i的初始值为1 */
    while(i<=1000000)
        do                  /* 对满足i<=100000的值进行while循环 */
    insert into t1(a,b) values(i, i); /* 写入表t1中a、b两个字段，值都为i当前的值 */
    set i=i+1;                      /* 将i加1 */
        end while;
end;

